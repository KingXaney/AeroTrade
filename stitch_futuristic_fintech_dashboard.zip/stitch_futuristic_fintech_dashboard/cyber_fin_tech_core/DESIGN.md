---
name: Cyber-Fin Tech Core
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#1e2024'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#d1bcff'
  on-secondary: '#3c0090'
  secondary-container: '#7000ff'
  on-secondary-container: '#ddcdff'
  tertiary: '#fff3f4'
  on-tertiary: '#66002c'
  tertiary-container: '#ffccd6'
  on-tertiary-container: '#bb0058'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d1bcff'
  on-secondary-fixed: '#23005b'
  on-secondary-fixed-variant: '#5700c9'
  tertiary-fixed: '#ffd9e0'
  tertiary-fixed-dim: '#ffb1c3'
  on-tertiary-fixed: '#3f0019'
  on-tertiary-fixed-variant: '#8f0041'
  background: '#111318'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 24px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system targets high-frequency traders and tech-forward investors who require high information density without sacrificing aesthetic sophistication. The brand personality is "Precision-Futurism": it is authoritative, hyper-efficient, and cinematic.

The visual style blends **Glassmorphism** with **Modern Minimalism**. It relies on deep obsidian backgrounds to provide maximum contrast for vibrant neon accents. The emotional response is one of total control and "HUD-like" immersion, mimicking advanced aerospace or data-center interfaces. Key characteristics include:
- Semi-transparent "frosted" glass panels that create a sense of digital depth.
- Subtle inner glows and hair-line borders that suggest energy-conducting circuitry.
- A focus on "active" states through light and color, rather than physical shadow.

## Colors

The palette is optimized for OLED displays and long-duration screen time.
- **Primary (Electric Blue):** Used for primary actions, active navigation, and data peaks.
- **Secondary (Cyber Purple):** Used for interactive secondary elements and subtle brand accents.
- **Tertiary (Cyber Pink):** Reserved for alerts, critical highlights, or differentiating specific asset classes.
- **Neutrals:** A spectrum of deep blacks and charcoals. The background is a "True Black" to let the glass panels float.
- **Status Colors:** High-saturation neon greens and reds for market movement, ensuring immediate legibility against the dark backdrop.

## Typography

The typography strategy prioritizes readability of complex data.
- **Sora** provides a high-tech, geometric feel for headings and display numbers.
- **Hanken Grotesk** is used for general interface text and descriptions, offering a clean, modern balance.
- **JetBrains Mono** is utilized for all financial figures, timestamps, and ticker symbols. The monospaced nature ensures that fluctuating numbers do not "jump" horizontally during live updates.

Mobile-specific adjustments: `display-lg` scales down to 32px on mobile devices, while `headline-lg` reduces to 24px to maintain layout integrity.

## Layout & Spacing

This design system uses a **Fluid Grid** based on a 4px baseline unit. 
- **Desktop:** 12-column grid with 24px margins. Content is organized into modular "widgets" that can span 3, 4, 6, or 12 columns.
- **Tablet:** 8-column grid with 16px margins. Sidebars collapse into drawers.
- **Mobile:** 4-column grid with 12px margins. Widgets stack vertically.

The rhythm is dense but breathable. High-priority data panels use generous internal padding (24px) to prevent visual clutter, while data tables use a tighter density (8px-12px) to maximize information visible above the fold.

## Elevation & Depth

Hierarchy is established through **Backdrop Blurs** and **Luminance** rather than traditional drop shadows.
- **Level 0 (Base):** The dark `#050608` canvas.
- **Level 1 (Panels):** Surface color with `backdrop-filter: blur(12px)`. These have a subtle `1px` border of `rgba(255, 255, 255, 0.1)`.
- **Level 2 (Modals/Popovers):** Higher blur (24px) and a brighter border. An "outer glow" effect is applied using a soft primary-colored shadow with 0% offset and 15px blur, but only when the element is active.
- **Interactive Depth:** On hover, panels increase in border opacity and the internal background becomes slightly lighter, simulating a "lift" toward the user's eye.

## Shapes

The shape language is **Technical and Crisp**. 
- Standard elements like buttons and input fields use a `4px` (Soft) radius to maintain a professional, engineered feel. 
- Larger containers and cards use a `8px` (rounded-lg) radius to define clear boundaries.
- Pill shapes are reserved exclusively for status indicators (e.g., "Active", "Pending") and small interactive tags.
- Avoid fully circular elements unless they are user avatars, to maintain the architectural, grid-based aesthetic.

## Components

- **Buttons:** Primary buttons feature a solid electric-blue background with a slight outer glow. Secondary buttons use a "ghost" style with a neon teal border.
- **Input Fields:** Dark, recessed backgrounds with a `1px` bottom-only border that glows primary-blue when focused. Labels always use the `label-caps` monospaced style.
- **Cards/Widgets:** Every widget must have a "Header" section containing the title in `headline-md` and a "Last Updated" timestamp in `data-mono`.
- **Data Visualizations:** Charts should use semi-transparent gradients under line paths. Grid lines within charts should be at 10% opacity to remain unobtrusive.
- **Chips/Tags:** Small, sharp-edged rectangles with low-opacity background fills matching their status color (e.g., a faint green background for "Buy" signals).
- **Glow Borders:** Use a CSS `conic-gradient` or `linear-gradient` for border-images to create the "circuitry" look on highlighted dashboard modules.